package tr.autoschematic.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Küçük çizim yardımcıları: yuvarlak dikdörtgen, renk dönüşümleri, çizgi, tuş adları. */
public final class Draw {
    private Draw() {
    }

    public static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int color) {
        c.drawTextWithShadow(tr, Text.literal(s), x, y, color);
    }

    public static void center(DrawContext c, TextRenderer tr, String s, int cx, int y, int color) {
        text(c, tr, s, cx - tr.getWidth(s) / 2, y, color);
    }

    /** Köşeleri yuvarlatılmış dolu dikdörtgen. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            c.fill(x, y, x + w, y + h, col);
            return;
        }
        c.fill(x + r, y, x + w - r, y + h, col);                       // orta sütun
        c.fill(x, y + r, x + r, y + h - r, col);                       // sol orta
        c.fill(x + w - r, y + r, x + w, y + h - r, col);               // sağ orta
        for (int j = 0; j < r; j++) {                                  // yuvarlak köşe basamakları
            double dy = r - j - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            c.fill(x + inset, y + j, x + r, y + j + 1, col);
            c.fill(x + w - r, y + j, x + w - inset, y + j + 1, col);
            c.fill(x + inset, y + h - 1 - j, x + r, y + h - j, col);
            c.fill(x + w - r, y + h - 1 - j, x + w - inset, y + h - j, col);
        }
    }

    /** İki ARGB rengi arasında doğrusal geçiş. */
    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int ab = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    /** HSB (0..1) -> 0xFFRRGGBB. */
    public static int hsb(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float f = h * 6.0f;
        int i = (int) f;
        float ff = f - i;
        float p = v * (1 - s);
        float q = v * (1 - s * ff);
        float t = v * (1 - s * (1 - ff));
        float r;
        float g;
        float b;
        switch (i % 6) {
            case 0 -> {
                r = v;
                g = t;
                b = p;
            }
            case 1 -> {
                r = q;
                g = v;
                b = p;
            }
            case 2 -> {
                r = p;
                g = v;
                b = t;
            }
            case 3 -> {
                r = p;
                g = q;
                b = v;
            }
            case 4 -> {
                r = t;
                g = p;
                b = v;
            }
            default -> {
                r = v;
                g = p;
                b = q;
            }
        }
        return 0xFF000000 | ((int) (r * 255 + 0.5f) << 16) | ((int) (g * 255 + 0.5f) << 8) | (int) (b * 255 + 0.5f);
    }

    /** RGB -> {h, s, b} (0..1). */
    public static float[] toHsb(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f;
        float g = ((rgb >> 8) & 255) / 255f;
        float b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float d = max - min;
        float h = 0;
        if (d > 0) {
            if (max == r) h = ((g - b) / d) % 6;
            else if (max == g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h /= 6f;
            if (h < 0) h += 1f;
        }
        float s = max == 0 ? 0 : d / max;
        return new float[]{h, s, max};
    }

    public static List<String> wrap(TextRenderer tr, String s, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String t = line.length() == 0 ? word : line + " " + word;
            if (tr.getWidth(t) > maxW && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(t);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    /** Ekran sınırlarına kırpılmış kalın çizgi (Liang-Barsky). */
    public static void line(DrawContext c, double x1, double y1, double x2, double y2,
                            int sw, int sh, int col, int th) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double t0 = 0;
        double t1 = 1;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x1, sw - x1, y1, sh - y1};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) {
                if (q[i] < 0) return;
            } else {
                double r = q[i] / p[i];
                if (p[i] < 0) {
                    if (r > t1) return;
                    if (r > t0) t0 = r;
                } else {
                    if (r < t0) return;
                    if (r < t1) t1 = r;
                }
            }
        }
        double ax = x1 + t0 * dx;
        double ay = y1 + t0 * dy;
        double bx = x1 + t1 * dx;
        double by = y1 + t1 * dy;
        int steps = (int) Math.min(1500, Math.max(Math.abs(bx - ax), Math.abs(by - ay)));
        if (steps < 1) {
            c.fill((int) ax, (int) ay, (int) ax + th, (int) ay + th, col);
            return;
        }
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            int px = (int) Math.round(ax + (bx - ax) * t);
            int py = (int) Math.round(ay + (by - ay) * t);
            c.fill(px, py, px + th, py + th, col);
        }
    }

    public static String keyName(int k) {
        if (k <= 0) return "Yok";
        switch (k) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT:
                return "R-Shift";
            case GLFW.GLFW_KEY_LEFT_SHIFT:
                return "L-Shift";
            case GLFW.GLFW_KEY_RIGHT_CONTROL:
                return "R-Ctrl";
            case GLFW.GLFW_KEY_LEFT_CONTROL:
                return "L-Ctrl";
            case GLFW.GLFW_KEY_RIGHT_ALT:
                return "R-Alt";
            case GLFW.GLFW_KEY_LEFT_ALT:
                return "L-Alt";
            case GLFW.GLFW_KEY_TAB:
                return "Tab";
            case GLFW.GLFW_KEY_SPACE:
                return "Space";
            case GLFW.GLFW_KEY_ENTER:
                return "Enter";
            case GLFW.GLFW_KEY_INSERT:
                return "Insert";
            case GLFW.GLFW_KEY_HOME:
                return "Home";
            case GLFW.GLFW_KEY_END:
                return "End";
            case GLFW.GLFW_KEY_PAGE_UP:
                return "PgUp";
            case GLFW.GLFW_KEY_PAGE_DOWN:
                return "PgDn";
            case GLFW.GLFW_KEY_UP:
                return "Yukarı";
            case GLFW.GLFW_KEY_DOWN:
                return "Aşağı";
            case GLFW.GLFW_KEY_LEFT:
                return "Sol";
            case GLFW.GLFW_KEY_RIGHT:
                return "Sağ";
            default:
                break;
        }
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        if (k >= GLFW.GLFW_KEY_KP_0 && k <= GLFW.GLFW_KEY_KP_9) return "Num " + (k - GLFW.GLFW_KEY_KP_0);
        String n = GLFW.glfwGetKeyName(k, 0);
        if (n != null && !n.isEmpty()) return n.toUpperCase(Locale.ROOT);
        return "Tuş " + k;
    }
}
