package tr.autoschematic.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Features;
import tr.autoschematic.core.Setting;

import java.util.ArrayList;
import java.util.List;

/**
 * Ana menü. Sol: kategoriler, orta: modüller, sağ: seçili modülün ayarları ve tuş ataması.
 * Her karede çizim sırasında "tıklanabilir alan" listesi (hits) çıkarılır; fare olayları bu listeyi kullanır.
 */
public class ClickGui extends Screen {
    private static Category lastCat = Category.COMBAT;

    private Category cat = lastCat;
    private Feature sel;
    private double modScroll;
    private double setScroll;
    private int modContentH;
    private int setContentH;
    private Feature binding;
    private Setting.Color openColor;
    private Hit dragging;
    private final List<Hit> hits = new ArrayList<>();

    private int x0;
    private int y0;
    private int winW;
    private int winH;
    private int mx1;
    private int my1;
    private int mx2;
    private int my2;
    private int sx1;
    private int sy1;
    private int sx2;
    private int sy2;

    private int clL = Integer.MIN_VALUE;
    private int clT = Integer.MIN_VALUE;
    private int clR = Integer.MAX_VALUE;
    private int clB = Integer.MAX_VALUE;

    private interface DragFn {
        void drag(double mx);
    }

    private static final class Hit {
        final int x;
        final int y;
        final int w;
        final int h;
        int cl;
        int ct;
        int cr;
        int cb;
        Runnable click;
        Runnable right;
        DragFn drag;

        Hit(int x, int y, int w, int h, int cl, int ct, int cr, int cb) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.cl = cl;
            this.ct = ct;
            this.cr = cr;
            this.cb = cb;
        }

        boolean contains(double mx, double my) {
            return mx >= Math.max(x, cl) && mx < Math.min(x + w, cr)
                    && my >= Math.max(y, ct) && my < Math.min(y + h, cb);
        }
    }

    public ClickGui() {
        super(Text.literal("Schematic Client"));
    }

    @Override
    protected void init() {
        if (sel == null || sel.cat != cat) sel = firstOf(cat);
    }

    private static Feature firstOf(Category c) {
        List<Feature> l = Features.of(c);
        return l.isEmpty() ? null : l.get(0);
    }

    // ------------------------------------------------------------------ yardımcılar

    private Hit hit(int x, int y, int w, int h) {
        Hit hh = new Hit(x, y, w, h, clL, clT, clR, clB);
        hits.add(hh);
        return hh;
    }

    private void setClip(int l, int t, int r, int b) {
        clL = l;
        clT = t;
        clR = r;
        clB = b;
    }

    private void resetClip() {
        clL = Integer.MIN_VALUE;
        clT = Integer.MIN_VALUE;
        clR = Integer.MAX_VALUE;
        clB = Integer.MAX_VALUE;
    }

    private boolean over(int mx, int my, int x, int y, int w, int h) {
        return mx >= Math.max(x, clL) && mx < Math.min(x + w, clR)
                && my >= Math.max(y, clT) && my < Math.min(y + h, clB);
    }

    private static double clamp01(double v) {
        return Math.max(0, Math.min(1, v));
    }

    private void pill(DrawContext ctx, int x, int y, float t) {
        int pw = 24;
        int ph = 12;
        Draw.rrect(ctx, x, y, pw, ph, 6, Draw.lerp(Theme.off(), Theme.accent(), t));
        int kx = x + 2 + Math.round((pw - ph) * t);
        Draw.rrect(ctx, kx, y + 2, ph - 4, ph - 4, 4, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ çizim

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        hits.clear();
        resetClip();
        winW = Math.min(540, this.width - 16);
        winH = Math.min(320, this.height - 16);
        x0 = (this.width - winW) / 2;
        y0 = (this.height - winH) / 2;
        int r = Theme.radius();
        TextRenderer tr = this.textRenderer;

        if (Features.GUI.dim.v) ctx.fill(0, 0, this.width, this.height, 0x55000000);
        Draw.rrect(ctx, x0 - 1, y0 - 1, winW + 2, winH + 2, r + 1, Theme.accentA(0x70));
        Draw.rrect(ctx, x0, y0, winW, winH, r, Theme.bg());

        Draw.text(ctx, tr, "SCHEMATIC", x0 + 12, y0 + 10, Theme.accent());
        Draw.text(ctx, tr, "CLIENT", x0 + 12 + tr.getWidth("SCHEMATIC "), y0 + 10, Theme.text());
        String hint = "1.21.11  |  " + Draw.keyName(Features.GUI.key) + " = aç/kapat";
        Draw.text(ctx, tr, hint, x0 + winW - 12 - tr.getWidth(hint), y0 + 10, Theme.sub());
        ctx.fill(x0 + 10, y0 + 26, x0 + winW - 10, y0 + 27, Theme.accentA(0x40));

        int sideW = 84;
        int top = y0 + 34;
        drawSidebar(ctx, mouseX, mouseY, sideW, top);

        mx1 = x0 + 8 + sideW + 8;
        mx2 = mx1 + (int) ((x0 + winW - 8 - mx1) * 0.40);
        my1 = top;
        my2 = y0 + winH - 8;
        sx1 = mx2 + 8;
        sx2 = x0 + winW - 8;
        sy1 = top;
        sy2 = my2;

        drawModules(ctx, mouseX, mouseY);
        drawSettings(ctx, mouseX, mouseY);
    }

    private void drawSidebar(DrawContext ctx, int mouseX, int mouseY, int sideW, int top) {
        TextRenderer tr = this.textRenderer;
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            final Category c = cats[i];
            int rx = x0 + 8;
            int ry = top + i * 26;
            int rw = sideW;
            int rh = 22;
            boolean selected = c == cat;
            boolean hov = over(mouseX, mouseY, rx, ry, rw, rh);
            if (selected) {
                Draw.rrect(ctx, rx, ry, rw, rh, 3, Theme.accentA(0x33));
                ctx.fill(rx, ry + 4, rx + 2, ry + rh - 4, Theme.accent());
            } else if (hov) {
                Draw.rrect(ctx, rx, ry, rw, rh, 3, Theme.rowHover());
            }
            Draw.text(ctx, tr, c.label, rx + 10, ry + 7, selected ? Theme.text() : Theme.sub());
            hit(rx, ry, rw, rh).click = () -> {
                cat = c;
                lastCat = c;
                sel = firstOf(c);
                modScroll = 0;
                setScroll = 0;
                openColor = null;
                binding = null;
            };
        }
    }

    private void drawModules(DrawContext ctx, int mouseX, int mouseY) {
        TextRenderer tr = this.textRenderer;
        Draw.rrect(ctx, mx1, my1, mx2 - mx1, my2 - my1, 4, Theme.panel());
        List<Feature> list = Features.of(cat);
        int rowH = 24;
        modContentH = list.size() * (rowH + 3) + 8;
        modScroll = Math.max(0, Math.min(modScroll, Math.max(0, modContentH - (my2 - my1))));

        ctx.enableScissor(mx1, my1, mx2, my2);
        setClip(mx1, my1, mx2, my2);
        int y = my1 + 4 - (int) modScroll;
        for (final Feature f : list) {
            int rx = mx1 + 4;
            int rw = mx2 - mx1 - 8;
            boolean isSel = f == sel;
            boolean hov = over(mouseX, mouseY, rx, y, rw, rowH);
            Draw.rrect(ctx, rx, y, rw, rowH, 3,
                    isSel ? Theme.accentA(0x2E) : (hov ? Theme.rowHover() : Theme.row()));
            if (isSel) ctx.fill(rx, y + 5, rx + 2, y + rowH - 5, Theme.accent());
            boolean lit = f.enabled || !f.toggleable();
            Draw.text(ctx, tr, f.name, rx + 9, y + 8, lit ? Theme.text() : Theme.sub());
            hit(rx, y, rw, rowH).click = () -> {
                sel = f;
                setScroll = 0;
                openColor = null;
                binding = null;
            };
            if (f.toggleable()) {
                f.anim += ((f.enabled ? 1f : 0f) - f.anim) * 0.25f;
                int px = rx + rw - 24 - 8;
                int py = y + (rowH - 12) / 2;
                pill(ctx, px, py, f.anim);
                hit(px - 3, py - 3, 30, 18).click = () -> {
                    f.toggle();
                    Features.save();
                };
            }
            y += rowH + 3;
        }
        ctx.disableScissor();
        resetClip();
    }

    private void drawSettings(DrawContext ctx, int mouseX, int mouseY) {
        TextRenderer tr = this.textRenderer;
        Draw.rrect(ctx, sx1, sy1, sx2 - sx1, sy2 - sy1, 4, Theme.panel());
        if (sel == null) {
            Draw.text(ctx, tr, "Soldan bir modül seç", sx1 + 10, sy1 + 10, Theme.sub());
            return;
        }
        setScroll = Math.max(0, Math.min(setScroll, Math.max(0, setContentH - (sy2 - sy1))));

        ctx.enableScissor(sx1, sy1, sx2, sy2);
        setClip(sx1, sy1, sx2, sy2);
        int px = sx1 + 8;
        int pw = sx2 - sx1 - 16;
        int startY = sy1 + 8 - (int) setScroll;
        int y = startY;

        Draw.text(ctx, tr, sel.name, px, y, Theme.accent());
        y += 12;
        for (String line : Draw.wrap(tr, sel.desc, pw)) {
            Draw.text(ctx, tr, line, px, y, Theme.sub());
            y += 10;
        }
        y += 6;
        y += drawBind(ctx, px, y, pw);
        ctx.fill(px, y, px + pw, y + 1, 0x22FFFFFF);
        y += 7;
        for (Setting s : sel.settings) {
            y += drawSetting(ctx, s, px, y, pw, mouseX, mouseY);
        }
        setContentH = (y - startY) + 16;
        ctx.disableScissor();
        resetClip();
    }

    private int drawBind(DrawContext ctx, int px, int y, int pw) {
        TextRenderer tr = this.textRenderer;
        final Feature f = sel;
        Draw.text(ctx, tr, "Tuş", px, y + 6, Theme.text());
        String label = binding == f ? "..." : Draw.keyName(f.key);
        int bw = 64;
        int bx = px + pw - bw;
        Draw.rrect(ctx, bx, y, bw, 20, 3, binding == f ? Theme.accentA(0x66) : Theme.row());
        Draw.center(ctx, tr, label, bx + bw / 2, y + 6, Theme.text());
        Hit h = hit(bx, y, bw, 20);
        h.click = () -> binding = (binding == f) ? null : f;
        h.right = () -> {
            if (f != Features.GUI) f.key = -1;
        };
        if (f != Features.GUI) {
            String ml = f.hold ? "Basılı tut" : "Aç/Kapa";
            int mw = 74;
            int mx = bx - mw - 6;
            Draw.rrect(ctx, mx, y, mw, 20, 3, Theme.row());
            Draw.center(ctx, tr, ml, mx + mw / 2, y + 6, Theme.sub());
            hit(mx, y, mw, 20).click = () -> f.hold = !f.hold;
        }
        return 26;
    }

    /** Bir ayarı çizer, kapladığı yüksekliği döndürür. */
    private int drawSetting(DrawContext ctx, Setting s, final int px, int y, final int pw, int mouseX, int mouseY) {
        TextRenderer tr = this.textRenderer;

        if (s instanceof Setting.Bool b) {
            Draw.text(ctx, tr, b.name, px, y + 6, Theme.text());
            pill(ctx, px + pw - 24, y + 4, b.v ? 1f : 0f);
            hit(px, y, pw, 20).click = () -> b.v = !b.v;
            return 24;
        }

        if (s instanceof Setting.Num n) {
            Draw.text(ctx, tr, n.name, px, y + 1, Theme.text());
            String vt = n.text();
            Draw.text(ctx, tr, vt, px + pw - tr.getWidth(vt), y + 1, Theme.accent());
            int by = y + 15;
            Draw.rrect(ctx, px, by, pw, 6, 3, Theme.off());
            int fw = (int) Math.round(pw * n.ratio());
            if (fw > 0) Draw.rrect(ctx, px, by, Math.max(fw, 4), 6, 3, Theme.accent());
            Draw.rrect(ctx, px + Math.max(0, Math.min(pw - 6, fw - 3)), by - 1, 6, 8, 3, 0xFFFFFFFF);
            Hit h = hit(px, y + 10, pw, 16);
            h.drag = mx -> n.set(n.min + clamp01((mx - px) / pw) * (n.max - n.min));
            return 32;
        }

        if (s instanceof Setting.Mode m) {
            Draw.text(ctx, tr, m.name, px, y + 6, Theme.text());
            String v = m.get();
            int bw = Math.max(60, Math.min(pw - tr.getWidth(m.name) - 12, tr.getWidth(v) + 28));
            int bx = px + pw - bw;
            Draw.rrect(ctx, bx, y, bw, 20, 3, Theme.row());
            Draw.center(ctx, tr, v, bx + bw / 2, y + 6, Theme.text());
            Draw.text(ctx, tr, "<", bx + 5, y + 6, Theme.sub());
            Draw.text(ctx, tr, ">", bx + bw - 11, y + 6, Theme.sub());
            Hit h = hit(bx, y, bw, 20);
            h.click = () -> m.step(1);
            h.right = () -> m.step(-1);
            return 24;
        }

        if (s instanceof Setting.Color c) {
            Draw.text(ctx, tr, c.name, px, y + 6, Theme.text());
            int sw = 34;
            int sxp = px + pw - sw;
            Draw.rrect(ctx, sxp - 1, y + 2, sw + 2, 16, 4, 0xFFFFFFFF);
            Draw.rrect(ctx, sxp, y + 3, sw, 14, 3, c.argb());
            hit(px, y, pw, 20).click = () -> openColor = (openColor == c) ? null : c;
            if (openColor != c) return 24;

            float[] hsb = Draw.toHsb(c.rgb);
            int by = y + 24;
            for (int i = 0; i < pw; i += 2) {
                ctx.fill(px + i, by, px + Math.min(pw, i + 2), by + 10, Draw.hsb(i / (float) pw, 1f, 1f));
                ctx.fill(px + i, by + 14, px + Math.min(pw, i + 2), by + 24,
                        Draw.hsb(hsb[0], i / (float) pw, Math.max(hsb[2], 0.3f)));
                ctx.fill(px + i, by + 28, px + Math.min(pw, i + 2), by + 38,
                        Draw.hsb(hsb[0], hsb[1], i / (float) pw));
            }
            int hx = px + (int) (hsb[0] * pw);
            int sx = px + (int) (hsb[1] * pw);
            int bx2 = px + (int) (hsb[2] * pw);
            ctx.fill(hx - 1, by - 1, hx + 1, by + 11, 0xFFFFFFFF);
            ctx.fill(sx - 1, by + 13, sx + 1, by + 25, 0xFFFFFFFF);
            ctx.fill(bx2 - 1, by + 27, bx2 + 1, by + 39, 0xFFFFFFFF);

            hit(px, by - 2, pw, 14).drag = mx -> {
                float[] cur = Draw.toHsb(c.rgb);
                float sat = cur[1] < 0.05f ? 1f : cur[1];
                float bri = cur[2] < 0.05f ? 1f : cur[2];
                c.set(Draw.hsb((float) clamp01((mx - px) / pw), sat, bri));
            };
            hit(px, by + 12, pw, 14).drag = mx -> {
                float[] cur = Draw.toHsb(c.rgb);
                c.set(Draw.hsb(cur[0], (float) clamp01((mx - px) / pw), Math.max(cur[2], 0.3f)));
            };
            hit(px, by + 26, pw, 14).drag = mx -> {
                float[] cur = Draw.toHsb(c.rgb);
                c.set(Draw.hsb(cur[0], cur[1], (float) clamp01((mx - px) / pw)));
            };
            return 24 + 44;
        }

        if (s instanceof Setting.Action a) {
            boolean hov = over(mouseX, mouseY, px, y, pw, 20);
            Draw.rrect(ctx, px, y, pw, 20, 3, hov ? Theme.accentA(0x66) : Theme.accentA(0x33));
            Draw.center(ctx, tr, a.name, px + pw / 2, y + 6, Theme.text());
            hit(px, y, pw, 20).click = a.run;
            return 24;
        }
        return 0;
    }

    // ------------------------------------------------------------------ giriş olayları

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int b = click.button();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            if (b == 0) {
                if (h.click != null) h.click.run();
                if (h.drag != null) {
                    dragging = h;
                    h.drag.drag(mx);
                }
            } else if (b == 1 && h.right != null) {
                h.right.run();
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging != null && dragging.drag != null) {
            dragging.drag.drag(click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragging != null) {
            dragging = null;
            Features.save();
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= mx1 && mouseX < mx2 && mouseY >= my1 && mouseY < my2) {
            modScroll -= verticalAmount * 18;
        } else if (mouseX >= sx1 && mouseX < sx2 && mouseY >= sy1 && mouseY < sy2) {
            setScroll -= verticalAmount * 18;
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (binding != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                binding = null;
                return true;
            }
            if (key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) binding.key = -1;
            else binding.key = key;
            if (binding == Features.GUI && binding.key <= 0) binding.key = GLFW.GLFW_KEY_RIGHT_SHIFT;
            binding = null;
            Features.save();
            return true;
        }
        if (Features.GUI.key > 0 && key == Features.GUI.key) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void removed() {
        Features.save();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
