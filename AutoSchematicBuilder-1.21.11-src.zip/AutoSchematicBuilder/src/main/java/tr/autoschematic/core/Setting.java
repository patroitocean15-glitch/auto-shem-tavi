package tr.autoschematic.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Bir modülün GUI'de görünen ayarı. Değerler config'e metin olarak yazılır. */
public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public abstract String save();

    public abstract void load(String s);

    public boolean persist() {
        return true;
    }

    /** Aç/kapa. */
    public static final class Bool extends Setting {
        public boolean v;

        public Bool(String name, boolean def) {
            super(name);
            this.v = def;
        }

        @Override
        public String save() {
            return Boolean.toString(v);
        }

        @Override
        public void load(String s) {
            v = Boolean.parseBoolean(s);
        }
    }

    /** Kaydırıcı (tam sayı ya da ondalık). */
    public static final class Num extends Setting {
        public double v;
        public final double min;
        public final double max;
        public final double step;

        public Num(String name, double def, double min, double max, double step) {
            super(name);
            this.min = min;
            this.max = max;
            this.step = step;
            this.v = def;
        }

        public int i() {
            return (int) Math.round(v);
        }

        public float f() {
            return (float) v;
        }

        public boolean isInt() {
            return step >= 1.0 && step == Math.floor(step);
        }

        public void set(double x) {
            double s = Math.round((x - min) / step) * step + min;
            v = Math.max(min, Math.min(max, s));
        }

        public double ratio() {
            return max == min ? 0 : (v - min) / (max - min);
        }

        public String text() {
            return isInt() ? Integer.toString(i()) : String.format(Locale.ROOT, "%.2f", v);
        }

        @Override
        public String save() {
            return Double.toString(v);
        }

        @Override
        public void load(String s) {
            try {
                set(Double.parseDouble(s));
            } catch (NumberFormatException ignored) {
                // bozuk değer: varsayılan kalsın
            }
        }
    }

    /** Seçenek listesi (tıkla = sonraki, sağ tık = önceki). */
    public static final class Mode extends Setting {
        public final List<String> opts;
        public int idx;
        public Runnable onChange;

        public Mode(String name, String... opts) {
            this(name, 0, opts);
        }

        public Mode(String name, int def, String... opts) {
            super(name);
            this.opts = new ArrayList<>(Arrays.asList(opts));
            this.idx = def;
        }

        public String get() {
            return opts.get(idx);
        }

        public void step(int dir) {
            int n = opts.size();
            idx = ((idx + dir) % n + n) % n;
            if (onChange != null) onChange.run();
        }

        @Override
        public String save() {
            return get();
        }

        @Override
        public void load(String s) {
            int k = opts.indexOf(s);
            if (k < 0) {          // config'e elle yazılmış özel değer: listeye ekle
                opts.add(0, s);
                k = 0;
            }
            idx = k;
        }
    }

    /** Renk seçici (RGB). */
    public static final class Color extends Setting {
        public int rgb;
        public Runnable onChange;

        public Color(String name, int rgb) {
            super(name);
            this.rgb = rgb & 0xFFFFFF;
        }

        public int argb() {
            return 0xFF000000 | rgb;
        }

        public int argb(int alpha) {
            return (alpha << 24) | rgb;
        }

        public void set(int newRgb) {
            this.rgb = newRgb & 0xFFFFFF;
            if (onChange != null) onChange.run();
        }

        @Override
        public String save() {
            return String.format("%06X", rgb);
        }

        @Override
        public void load(String s) {
            try {
                rgb = Integer.parseInt(s, 16) & 0xFFFFFF;
            } catch (NumberFormatException ignored) {
                // bozuk değer
            }
        }
    }

    /** Tıklanınca bir iş yapan düğme (kaydedilmez). */
    public static final class Action extends Setting {
        public final Runnable run;

        public Action(String name, Runnable run) {
            super(name);
            this.run = run;
        }

        @Override
        public String save() {
            return "";
        }

        @Override
        public void load(String s) {
            // kaydedilmez
        }

        @Override
        public boolean persist() {
            return false;
        }
    }
}
