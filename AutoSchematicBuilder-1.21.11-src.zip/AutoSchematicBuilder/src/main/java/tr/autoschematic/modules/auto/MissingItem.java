package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import tr.autoschematic.Materials;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Features;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Hud;

import java.util.Map;

/**
 * Şematik için gereken ama envanterde olmayan eşyayı, ayarlanan market komutuyla otomatik alır.
 * Komut şablonu: {item} = stone_bricks gibi kimlik, {item_name} = görünen ad, {amount} = miktar.
 * Farklı bir komut için config/autoschematic.json içindeki "Satın alma komutu" değerini düzenleyebilirsin.
 */
public final class MissingItem extends Feature {
    private final Setting.Mode command = add(new Setting.Mode("Satın alma komutu",
            "/buy {item} {amount}",
            "/market buy {item} {amount}",
            "/shop buy {item} {amount}",
            "/satinal {item} {amount}",
            "/pazar al {item} {amount}"));
    private final Setting.Num amount = add(new Setting.Num("Miktar", 64, 1, 64, 1));
    private final Setting.Num seconds = add(new Setting.Num("İki komut arası (sn)", 5, 2, 60, 1));
    private final Setting.Bool needBuilder = add(new Setting.Bool("Sadece şematik inşa açıkken", true));
    private final Setting.Bool showHud = add(new Setting.Bool("Eksikleri ekrana yaz", true));
    @SuppressWarnings("unused")
    private final Setting.Action list = add(new Setting.Action("Eksikleri sohbette listele (24 blok)",
            MissingItem::listMissing));

    private int cooldown;

    public MissingItem() {
        super("Auto Missing Item",
                "Şematikte eksik olan eşyaları market komutuyla otomatik alır. Şematik inşa açıkken çalışır.",
                Category.AUTO);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (cooldown > 0) cooldown--;
        if (needBuilder.v && !Features.BUILDER.enabled) return;
        if (cooldown > 0 || mc.getNetworkHandler() == null) return;

        Item top = Features.BUILDER.topMissing();
        if (top == null) return;

        String cmd = command.get().trim();
        if (cmd.isEmpty()) return;
        cmd = cmd.replace("{item}", Registries.ITEM.getId(top).getPath())
                .replace("{item_name}", top.getName().getString())
                .replace("{amount}", Integer.toString(amount.i()));
        if (cmd.startsWith("/")) cmd = cmd.substring(1);

        mc.getNetworkHandler().sendChatCommand(cmd);
        cooldown = Math.max(20, seconds.i() * 20);
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        if (!showHud.v) return;
        Map<Item, Integer> miss = Features.BUILDER.missing;
        if (miss.isEmpty()) return;
        Hud.left(ctx, mc, "Eksik malzeme:", 0xFFFFD166);
        int n = 0;
        for (Map.Entry<Item, Integer> e : miss.entrySet()) {
            if (n++ >= 5) break;
            Hud.left(ctx, mc, " " + e.getKey().getName().getString() + " x" + e.getValue(), 0xFFE0E0E0);
        }
    }

    private static void listMissing() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Materials.scan(mc, 24);
        Util.chat(mc, Text.literal("[AutoSchem] " + Materials.note).formatted(Formatting.AQUA));
        int n = 0;
        for (Materials.Row r : Materials.rows) {
            if (n++ >= 12) break;
            Text t = Text.literal(" - " + r.item.getName().getString() + ": ")
                    .append(Text.literal(r.have + "/" + r.need)
                            .formatted(r.have >= r.need ? Formatting.GREEN : Formatting.RED));
            Util.chat(mc, t);
        }
    }
}
