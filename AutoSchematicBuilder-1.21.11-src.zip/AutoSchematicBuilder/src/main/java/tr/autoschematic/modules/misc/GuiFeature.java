package tr.autoschematic.modules.misc;

import org.lwjgl.glfw.GLFW;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Menü teması ve menüyü açan tuş (varsayılan: Sağ Shift). */
public final class GuiFeature extends Feature {
    private static final int[] PRESETS = {
            0x3FA9F5, 0x9B6BFF, 0xFF4D4D, 0x3DDC84, 0xFF6FB5, 0xFF9F43, 0x2EE6D6, 0xF5C542};

    public final Setting.Mode preset = add(new Setting.Mode("Hazır tema",
            "Mavi", "Mor", "Kırmızı", "Yeşil", "Pembe", "Turuncu", "Camgöbeği", "Altın", "Özel"));
    public final Setting.Color accent = add(new Setting.Color("Vurgu rengi", 0x3FA9F5));
    public final Setting.Num opacity = add(new Setting.Num("Arka plan opaklığı", 235, 90, 255, 5));
    public final Setting.Num radius = add(new Setting.Num("Köşe yuvarlaklığı", 4, 0, 8, 1));
    public final Setting.Bool dim = add(new Setting.Bool("Arkaplanı karart", true));

    public GuiFeature() {
        super("GUI", "Menü rengi, opaklığı ve köşeleri. Menüyü açan tuşu aşağıdaki 'Tuş' kutusundan değiştirebilirsin.",
                Category.THEME);
        key = GLFW.GLFW_KEY_RIGHT_SHIFT;
        enabled = true;
        preset.onChange = () -> {
            if (preset.idx < PRESETS.length) accent.rgb = PRESETS[preset.idx];
        };
        accent.onChange = () -> preset.idx = PRESETS.length;
    }

    @Override
    public boolean toggleable() {
        return false;
    }
}
