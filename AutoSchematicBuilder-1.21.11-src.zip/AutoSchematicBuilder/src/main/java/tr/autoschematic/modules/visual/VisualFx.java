package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import tr.autoschematic.core.Features;

/** Mixin'lerin çağırdığı görsel yardımcılar (el dönüşümü ve FOV). */
public final class VisualFx {
    private VisualFx() {
    }

    /** renderFirstPersonItem başında çağrılır: matrisi Hand View / Better Item'e göre değiştirir. */
    public static void hand(MatrixStack m, Hand hand, ItemStack item, AbstractClientPlayerEntity player) {
        HandView hv = Features.HAND_VIEW;
        BetterItem bi = Features.BETTER_ITEM;
        if (hv == null || bi == null) return;

        boolean rightArm = (hand == Hand.MAIN_HAND) == (player.getMainArm() == Arm.RIGHT);
        double side = rightArm ? 1.0 : -1.0;
        // Eşyanın kamera uzayındaki yaklaşık konumu (vanilla: 0.56, -0.52, -0.72)
        double px = 0.56 * side;
        double py = -0.52;
        double pz = -0.72;

        if (bi.enabled && !item.isEmpty()) {
            m.translate(0.0, bi.hover.v, 0.0);
            m.translate(px, py, pz);
            if (bi.spin.v) {
                double deg = (System.currentTimeMillis() % 3600000L) / 1000.0 * bi.speed.v;
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) (deg % 360.0)));
            }
            float s = bi.size.f();
            m.scale(s, s, s);
            m.translate(-px, -py, -pz);
        }

        if (hv.enabled) {
            m.translate(hv.x.v * side, hv.y.v, hv.z.v);
            m.translate(px, py, pz);
            if (hv.rotX.v != 0) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(hv.rotX.f()));
            if (hv.rotY.v != 0) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(hv.rotY.f()));
            if (hv.rotZ.v != 0) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(hv.rotZ.f()));
            float s = hv.scale.f();
            m.scale(s, s, s);
            m.translate(-px, -py, -pz);
        }
    }

    /**
     * GameRenderer.getFov dönüş değerini değiştirir. null = dokunma.
     * changingFov=true: dünya görüşü (Custom FOV), false: el görüşü (Hand Aura).
     */
    public static Float fov(float original, boolean changingFov) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (changingFov) {
            CustomFov cf = Features.CUSTOM_FOV;
            if (cf != null && cf.enabled) {
                float base = mc.options.getFov().getValue();
                float ratio = base > 0 ? original / base : 1f;   // koşma/yay gibi FOV efektlerini koru
                return cf.fov.f() * ratio;
            }
        } else {
            HandAura ha = Features.HAND_AURA;
            if (ha != null && ha.enabled && ha.handFov.v) return ha.fov.f();
        }
        return null;
    }
}
