package tr.autoschematic.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/**
 * Yakınına başka bir oyuncu gelirse sunucudan çıkar (AFK güvenliği). Çıkış ekranında
 * "Player Detect: nick" yazar. "Sadece uyar" açıksa çıkmaz, sadece ekranda haber verir.
 */
public final class PlayerDetect extends Feature {
    private final Setting.Num radius = add(new Setting.Num("Mesafe (blok)", 24, 4, 128, 2));
    private final Setting.Bool alertOnly = add(new Setting.Bool("Sadece uyar (çıkma)", false));
    private int t;
    private String lastAlert = "";

    public PlayerDetect() {
        super("Player Detect",
                "Yakınına bir oyuncu gelirse sunucudan çıkar; çıkış ekranında 'Player Detect: nick' yazar.",
                Category.MISC);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (++t % 4 != 0) return;
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null) return;

        for (AbstractClientPlayerEntity other : mc.world.getPlayers()) {
            if (other == me || other.isSpectator()) continue;
            if (me.distanceTo(other) > radius.v) continue;
            String nick = other.getName().getString();

            if (alertOnly.v) {
                if (!nick.equals(lastAlert)) {
                    lastAlert = nick;
                    Util.info(mc, "Player Detect: " + nick + " yakınında");
                }
                return;
            }
            ClientPlayNetworkHandler h = mc.getNetworkHandler();
            setEnabled(false);
            if (h != null) {
                h.getConnection().disconnect(Text.literal("Player Detect: " + nick));
            }
            return;
        }
        lastAlert = "";
    }
}
