package tr.autoschematic.modules.auto;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import tr.autoschematic.Look;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Features;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Draw;
import tr.autoschematic.gui.Hud;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Yüklü chunk'lardaki tüm mob spawner'ları bulur; ekranda kırmızı çubuk, chunk çerçevesi ve etiketle işaretler,
 * ilk bulunduğunda uyarı verir. İşaretler ekran uzayında çizilir (duvarların arkasından da görünür).
 */
public final class SpawnerDetect extends Feature {
    private final Setting.Num chunks = add(new Setting.Num("Tarama yarıçapı (chunk)", 12, 2, 32, 1));
    private final Setting.Bool warn = add(new Setting.Bool("Uyarı ver", true));
    private final Setting.Bool beam = add(new Setting.Bool("Kırmızı çubuk", true));
    private final Setting.Bool chunkBox = add(new Setting.Bool("Chunk çerçevesi", true));
    private final Setting.Bool list = add(new Setting.Bool("Liste göster", true));
    private final Setting.Color color = add(new Setting.Color("İşaret rengi", 0xFF3B30));

    private final List<BlockPos> found = new ArrayList<>();
    private final Set<Long> announced = new HashSet<>();
    private int tick;
    private int flash;

    public SpawnerDetect() {
        super("Auto Spawner Detect",
                "Yüklü chunk'lardaki tüm spawner'ları kırmızı çubuk + chunk çerçevesiyle işaretler ve uyarır.",
                Category.AUTO);
    }

    @Override
    public void onDisable() {
        found.clear();
        announced.clear();
        flash = 0;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (flash > 0) flash--;
        if (++tick % 20 != 1) return;
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        if (w == null || p == null) return;

        int pcx = p.getBlockX() >> 4;
        int pcz = p.getBlockZ() >> 4;
        int r = Math.min(chunks.i(), mc.options.getViewDistance().getValue());
        List<BlockPos> out = new ArrayList<>();
        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                Chunk ch = w.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (ch == null) continue;
                for (BlockPos bp : ch.getBlockEntityPositions()) {
                    if (w.getBlockState(bp).isOf(Blocks.SPAWNER)) out.add(bp.toImmutable());
                }
            }
        }
        out.sort(Comparator.comparingDouble((BlockPos b) -> b.getSquaredDistance(p.getBlockPos())));
        found.clear();
        found.addAll(out);

        for (BlockPos bp : out) {
            if (announced.add(bp.asLong()) && warn.v) {
                String xyz = bp.getX() + " " + bp.getY() + " " + bp.getZ();
                Util.info(mc, "SPAWNER bulundu: " + xyz);
                Util.chat(mc, Text.literal("[AutoSchem] SPAWNER bulundu: " + xyz).formatted(Formatting.RED));
                flash = 100;
            }
        }
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        if (flash > 0 && (flash / 5) % 2 == 0) {
            String s = "[!] SPAWNER ALGILANDI (" + found.size() + ")";
            Draw.center(ctx, mc.textRenderer, s, sw / 2, 22, color.argb());
        }
        if (found.isEmpty()) return;

        if (list.v) {
            Hud.left(ctx, mc, "Spawner: " + found.size(), color.argb());
            for (int i = 0; i < Math.min(5, found.size()); i++) {
                BlockPos b = found.get(i);
                int d = (int) Math.sqrt(b.getSquaredDistance(p.getBlockPos()));
                Hud.left(ctx, mc, " " + b.getX() + " " + b.getY() + " " + b.getZ() + "  (" + d + "m)", 0xFFE0E0E0);
            }
        }

        float yaw = Look.active ? Look.yaw : p.getYaw(tickProgress);
        float pitch = Look.active ? Look.pitch : p.getPitch(tickProgress);
        double fov = Features.CUSTOM_FOV.enabled ? Features.CUSTOM_FOV.fov.v : mc.options.getFov().getValue();
        Cam cam = new Cam(p.getEyePos(), yaw, pitch, fov, sw, sh);

        int col = color.argb();
        int lineCol = color.argb(0xD0);
        int n = Math.min(20, found.size());
        for (int i = 0; i < n; i++) {
            BlockPos b = found.get(i);
            double cx = b.getX() + 0.5;
            double cy = b.getY() + 0.5;
            double cz = b.getZ() + 0.5;

            if (beam.v) cam.line(ctx, cx, cy - 96, cz, cx, cy + 96, cz, lineCol, 2);
            if (chunkBox.v) {
                double x0 = (b.getX() >> 4) * 16.0;
                double z0 = (b.getZ() >> 4) * 16.0;
                double x1 = x0 + 16;
                double z1 = z0 + 16;
                int boxCol = color.argb(0x90);
                cam.line(ctx, x0, cy, z0, x1, cy, z0, boxCol, 1);
                cam.line(ctx, x1, cy, z0, x1, cy, z1, boxCol, 1);
                cam.line(ctx, x1, cy, z1, x0, cy, z1, boxCol, 1);
                cam.line(ctx, x0, cy, z1, x0, cy, z0, boxCol, 1);
            }
            double[] s = cam.project(cx, cy, cz);
            if (s != null) {
                int px = (int) s[0];
                int py = (int) s[1];
                ctx.fill(px - 3, py - 3, px + 4, py + 4, col);
                ctx.fill(px - 1, py - 1, px + 2, py + 2, 0xFFFFFFFF);
                int d = (int) Math.sqrt(b.getSquaredDistance(p.getBlockPos()));
                Draw.center(ctx, mc.textRenderer, "SPAWNER  " + d + "m", px, py - 14, col);
            }
        }
    }

    /** Basit perspektif kamera: dünya noktalarını ekran koordinatına çevirir. */
    private static final class Cam {
        private final Vec3d eye;
        private final double[] f = new double[3];
        private final double[] r = new double[3];
        private final double[] u = new double[3];
        private final double tx;
        private final double ty;
        private final int sw;
        private final int sh;

        Cam(Vec3d eye, float yawDeg, float pitchDeg, double fovDeg, int sw, int sh) {
            this.eye = eye;
            this.sw = sw;
            this.sh = sh;
            double yaw = Math.toRadians(yawDeg);
            double pitch = Math.toRadians(pitchDeg);
            f[0] = -Math.sin(yaw) * Math.cos(pitch);
            f[1] = -Math.sin(pitch);
            f[2] = Math.cos(yaw) * Math.cos(pitch);
            r[0] = -Math.cos(yaw);
            r[1] = 0;
            r[2] = -Math.sin(yaw);
            u[0] = r[1] * f[2] - r[2] * f[1];
            u[1] = r[2] * f[0] - r[0] * f[2];
            u[2] = r[0] * f[1] - r[1] * f[0];
            this.ty = Math.tan(Math.toRadians(fovDeg) / 2.0);
            this.tx = ty * ((double) sw / (double) sh);
        }

        /** Kamera uzayı: {sağ, yukarı, ileri}. */
        private double[] toCam(double x, double y, double z) {
            double dx = x - eye.x;
            double dy = y - eye.y;
            double dz = z - eye.z;
            return new double[]{
                    dx * r[0] + dy * r[1] + dz * r[2],
                    dx * u[0] + dy * u[1] + dz * u[2],
                    dx * f[0] + dy * f[1] + dz * f[2]};
        }

        private double[] screen(double[] c) {
            return new double[]{
                    (c[0] / (c[2] * tx) * 0.5 + 0.5) * sw,
                    (0.5 - c[1] / (c[2] * ty) * 0.5) * sh};
        }

        double[] project(double x, double y, double z) {
            double[] c = toCam(x, y, z);
            if (c[2] < 0.1) return null;
            return screen(c);
        }

        void line(DrawContext ctx, double ax, double ay, double az, double bx, double by, double bz,
                  int col, int th) {
            double[] a = toCam(ax, ay, az);
            double[] b = toCam(bx, by, bz);
            double near = 0.1;
            if (a[2] < near && b[2] < near) return;
            if (a[2] < near) a = clip(a, b, near);
            else if (b[2] < near) b = clip(b, a, near);
            double[] sa = screen(a);
            double[] sb = screen(b);
            Draw.line(ctx, sa[0], sa[1], sb[0], sb[1], sw, sh, col, th);
        }

        private static double[] clip(double[] behind, double[] front, double near) {
            double t = (near - behind[2]) / (front[2] - behind[2]);
            return new double[]{
                    behind[0] + (front[0] - behind[0]) * t,
                    behind[1] + (front[1] - behind[1]) * t,
                    near};
        }
    }
}
