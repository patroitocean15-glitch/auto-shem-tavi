package tr.autoschematic;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Oyuncunun çevresindeki (yarıçap) eksik blokları sayar; envanterle karşılaştırır. */
public final class Materials {
    private Materials() {
    }

    public static final class Row {
        public final Item item;
        public final int need;
        public final int have;

        Row(Item item, int need, int have) {
            this.item = item;
            this.need = need;
            this.have = have;
        }
    }

    public static List<Row> rows = new ArrayList<>();
    public static int totalMissing;
    public static String note = "Henüz hesaplanmadı";

    public static void scan(MinecraftClient mc, int radius) {
        rows = new ArrayList<>();
        totalMissing = 0;
        ClientWorld w = mc.world;
        if (mc.player == null || w == null) {
            note = "Oyunda değilsin";
            return;
        }
        World sw = Litema.schematicWorld();
        if (sw == null) {
            note = "Şematik yok (Litematica yüklü mü? Şematik yerleştirdin mi?)";
            return;
        }

        Map<Item, Integer> need = new HashMap<>();
        BlockPos base = mc.player.getBlockPos();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    BlockState want = sw.getBlockState(pos);
                    if (want.isAir()) continue;
                    BlockState have = w.getBlockState(pos);
                    if (have == want) continue;
                    if (!have.isAir() && !have.isReplaceable()) continue;
                    Item it = want.getBlock().asItem();
                    if (it == Items.AIR) continue;
                    need.merge(it, 1, Integer::sum);
                    totalMissing++;
                }
            }
        }

        PlayerInventory inv = mc.player.getInventory();
        for (Map.Entry<Item, Integer> e : need.entrySet()) {
            int have = 0;
            for (int i = 0; i < 36; i++) {
                ItemStack s = inv.getStack(i);
                if (s.isOf(e.getKey())) have += s.getCount();
            }
            rows.add(new Row(e.getKey(), e.getValue(), have));
        }
        rows.sort(Comparator.comparingInt((Row r) -> r.need).reversed());
        note = "Yarıçap " + radius + " blok, eksik toplam: " + totalMissing;
    }
}
